The Transpear XP components were written 
to be used in Transpear Fusion Band, they
give a rather unique XP feel too an application
they work with both Delphi 5 and 6
and are compatible with all versions of
Windows.

Included components:

XP_Form      - Gives your form an XP appearance.
XP_Button    - Office XP style bytton.
XP_Edit      - Office XP Edit Box.
XP_ListBox   - XP Style ListBox.
XP_IconBox   - XP Styled Icon list box, reads from a EXE/DLL etc.
XP_MainMenu  - Office XP Style main menu.
XP_PopUpMenu - Office XP Style main menu.
XP_Tree      - XP Styled TreeView.
XP_MenuBar   - Standard menuBar modified too work with XP_MainMenu.
XP_DriveMenu - Popup Menu that shows all current drives.

and lots more ...



