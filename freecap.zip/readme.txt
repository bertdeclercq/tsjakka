                            FreeCap

if you have FreeCap 3.16 installed on your system, deinstall it for avoiding possible conflicts


This program is "more" freeware version of SocksCap (c) by Permeo Technologies.
This program allows you to run programs that operate with WinSock 
(such as: Internet Explorer, Netscape etc) transparently redirecting all 
network traffic via SOCKS server.



BUILD:
  For build you need Delphi5 or higher. If you have $(DELPHI)\Bin in the your
  $PATH environment variable, you can just type 'make' in program root.
  Executables will be placed in "exe" directory

  If you're compiling from the IDE, install before compiling components placed in "components\" 
  folder


Program files has detailed comments in english. Since english isn't my native 
language sorry for grammar mistakes, etc :)

This project contains three methods of injection. It also contains
protect from WinSock anti-hook protection. (Huh, cool phrase :))

If you have an ideas/comments/suggestion/bug reports send it
me at bert@freecap.ru or to ICQ: 320531023



----
Sincerly yours, Max Artemev aka Bert (bert@freecap.ru), 
I-tel Internet Services Provider (www.i-tel.ru)
Freecap homepage: http://www.freecap.ru/


